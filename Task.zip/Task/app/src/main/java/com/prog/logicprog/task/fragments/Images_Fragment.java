package com.prog.logicprog.task.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.prog.logicprog.task.R;

import ss.com.bannerslider.banners.DrawableBanner;
import ss.com.bannerslider.views.BannerSlider;

/**
 * Created by logicprog on 5/19/2017.
 */

public class Images_Fragment extends Fragment {

    BannerSlider bannerSlider;

    public Images_Fragment(){

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.image_fragment, container, false);
        bannerSlider= (BannerSlider) view.findViewById(R.id.banner_slider1);
        bannerSlider.addBanner(new DrawableBanner(R.drawable.image1));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.image2));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.image3));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.image1));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.image2));
        return view;
    }

}
