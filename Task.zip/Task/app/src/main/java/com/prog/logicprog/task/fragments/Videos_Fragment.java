package com.prog.logicprog.task.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.prog.logicprog.task.Activity.Videos;
import com.prog.logicprog.task.R;

import ss.com.bannerslider.banners.DrawableBanner;
import ss.com.bannerslider.events.OnBannerClickListener;
import ss.com.bannerslider.views.BannerSlider;

/**
 * Created by logicprog on 5/19/2017.
 */

public class Videos_Fragment extends Fragment {
    BannerSlider bannerSlider;

    public Videos_Fragment(){

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.video_fragment, container, false);
        bannerSlider= (BannerSlider) view.findViewById(R.id.banner_slider1);
        bannerSlider.addBanner(new DrawableBanner(R.drawable.video_thumbnail));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.video_thumbnail1));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.video_thumbnail2));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.video_thumbnail3));
        bannerSlider.addBanner(new DrawableBanner(R.drawable.video_thumbnail2));

        bannerSlider.setOnBannerClickListener(new OnBannerClickListener() {
            @Override
            public void onClick(int position) {
                Intent intent=new Intent(getActivity(), Videos.class);
                startActivity(intent);
                getActivity().finish();
            }
        });
        return view;
    }


}
