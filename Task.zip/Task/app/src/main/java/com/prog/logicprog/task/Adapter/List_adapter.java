package com.prog.logicprog.task.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.prog.logicprog.task.R;
import com.prog.logicprog.task.List_Content.list_content;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class List_adapter extends BaseAdapter {
    Context context;
    ArrayList<list_content> feedsarray;

    int selectedposition;

    public List_adapter(Context context, ArrayList<list_content> feedsarray) {
        this.context = context;
        this.feedsarray = feedsarray;


    }

    /* private view holder class */
    private class ViewHolder {
        TextView title,time,description;
        ImageView imagepath;

    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;


        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = mInflater.inflate(R.layout.list_item, null);
        holder = new ViewHolder();

        holder.title= (TextView) convertView.findViewById(R.id.title);
        holder.time = (TextView) convertView.findViewById(R.id.time);
        holder.description = (TextView) convertView.findViewById(R.id.description);
        holder.imagepath=(ImageView)convertView.findViewById(R.id.image);
        Picasso.with(context)
                .load(feedsarray.get(position).getImagepath())
                .into(holder.imagepath);

        holder.title.setText(feedsarray.get(position).getTitle());
        holder.time.setText(feedsarray.get(position).getTime());
        holder.description.setText(feedsarray.get(position).getDescription());

        return convertView;

    }

    public int getCount() {
        return feedsarray.size();
    }

    public Object getItem(int position) {
        return feedsarray.get(position);
    }

    public long getItemId(int position) {
        return feedsarray.indexOf(getItem(position));
    }



}