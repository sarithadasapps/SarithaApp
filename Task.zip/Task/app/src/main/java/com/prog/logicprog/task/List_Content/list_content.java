package com.prog.logicprog.task.List_Content;

/**
 * Created by logicprog on 5/18/2017.
 */

public class list_content {
    String imagepath;
    String title;
    String time;

    public String getImagepath() {
        return imagepath;
    }

    public void setImagepath(String imagepath) {
        this.imagepath = imagepath;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    String description;

    public list_content(String imagepath,String title,String time,String description){
        this.imagepath=imagepath;
        this.title=title;
        this.time=time;
        this.description=description;
    }
}
