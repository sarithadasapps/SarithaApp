package com.iprismtech.healthyhome.mvp.base;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.iprismtech.healthyhome.mvp.contract.HomeActivityContract.IPermissionIds.REQUEST_TO_GET_HOME_FRAGMENT_SCREEN;


public interface IBaseContract {

    /**
     * Annotations for events id
     * Make here if events id are common
     * otherwise maintain in base class
     */
    @Retention(RetentionPolicy.CLASS)
    @IntDef({REQUEST_TO_GET_HOME_FRAGMENT_SCREEN})
    @interface PermissionIds {

    }
}