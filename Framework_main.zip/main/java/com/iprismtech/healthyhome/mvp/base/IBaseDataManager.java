package com.iprismtech.healthyhome.mvp.base;

/**
 * Created by Prasad on 05/07/2017.
 */
public interface IBaseDataManager {

    void initialize();

    void destroy();
}
