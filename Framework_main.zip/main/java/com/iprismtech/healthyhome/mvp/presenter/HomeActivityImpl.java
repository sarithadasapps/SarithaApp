package com.iprismtech.healthyhome.mvp.presenter;


import android.content.Context;
import android.support.annotation.Nullable;

import com.iprismtech.healthyhome.mvp.base.BasePresenter;
import com.iprismtech.healthyhome.mvp.contract.HomeActivityContract;
import com.iprismtech.healthyhome.network.listener.APIResponseCallback;

import org.json.JSONObject;

/**
 * Created by Prasad on 7/5/2017.
 */
public class HomeActivityImpl extends BasePresenter implements HomeActivityContract.IPresenter,APIResponseCallback {

    private Context context;
    private HomeActivityContract.IView maincontentview;
    private APIResponseCallback apiResponseCallback;

    public HomeActivityImpl(Context context, HomeActivityContract.IView maincontentview) {
        super(maincontentview, context);
        this.context = context;
        this.maincontentview = maincontentview;
    }






    @Override
    public void onSuccessResponse(int requestId, JSONObject responseJsonObject, @Nullable Object object) {
        super.onSuccessResponse(requestId, responseJsonObject, object);
        System.out.println("This is response from the server as success");
        if(apiResponseCallback!=null){
            apiResponseCallback.onSuccessResponse(requestId,responseJsonObject,null);
        }
    }

    @Override
    public void onFailureResponse(int requestId, JSONObject errorJsonObject) {
        super.onFailureResponse(requestId, errorJsonObject);
        System.out.println("This is response from the server as failed");
    }


}
