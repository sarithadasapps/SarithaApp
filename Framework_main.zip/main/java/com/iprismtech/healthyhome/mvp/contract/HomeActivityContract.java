package com.iprismtech.healthyhome.mvp.contract;

import android.support.v4.app.Fragment;

import com.iprismtech.healthyhome.mvp.base.IBaseContract;
import com.iprismtech.healthyhome.mvp.base.IBaseDataManager;


public interface HomeActivityContract {

    /**
     * Declare the event id's which will be handle for Home screen.
     */
    interface IPermissionIds extends IBaseContract {
        int REQUEST_TO_GET_HOME_FRAGMENT_SCREEN=16;
    }

    /**
     * Declare the method here which can be use in Home screen.
     */
    interface IView{
        /**
         * Here, the fragment launching code id written. This method add the fragment above existing fragment.
         *
         * @param fragment Fragment To Launch.
         */
        void addRespectiveFragment(Fragment fragment, int data);

        /**
         * Here, the fragment launching code id written. This method replace the fragment above existing fragment.
         *
         * @param fragment Fragment To Launch.
         */
        void replaceRespectiveFragment(Fragment fragment, String[] data, String tag);

    }


    /**
     * Declared the methods here which can be used in Singup Screen.
     */
    interface IPresenter {


    }

    /**
     * Declared the methods here which can be used in Data manager of Signup Screen.
     */
    interface IDataManager extends IBaseDataManager {


    }

}
