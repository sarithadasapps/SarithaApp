package com.iprismtech.healthyhome.app.constants;

/**
 * Created by Prasad on 7/13/2017.
 */
public class UiAppConstant {

    public static final int PLAY_SERVICES_RESOLUTION_REQUEST = 100;
    public static String inWhichCurrentFragment = "";
    public static String homeFragment="Home", Fragexam="Exam",FragInstructions="Instructions",Fragresult="Result",
            Fragnotifications="Notifications",FragReport="Report";


    public static String[] menuItems = new String[]{homeFragment,Fragnotifications,FragReport,"","",""};

    public static String email="",phno="",name="",area="",place="",city="",state="",country="",postcode="";


}