package com.iprismtech.healthyhome.app.factories;

import android.support.annotation.IntDef;

import com.iprismtech.healthyhome.activity.ActivityLogin;
import com.iprismtech.healthyhome.app.controller.ApplicationController;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.iprismtech.healthyhome.app.factories.ViewFactory.ScreenIds.LOGIN_SCREEN;

/**
 * Created by prasad on 05/07/2017.
 * ViewFactory.java The Class which returns the Class (Screen) to the
 * application frame. Developer should use this class to get the reference of
 * any screen in the application. He should not create the screen by him/her
 * self
 */
public class ViewFactory {

    @Retention(RetentionPolicy.CLASS)
    @IntDef({LOGIN_SCREEN})
    public @interface ScreenIds {
        int VIEWPAGER = 1000;
        int LOGIN_SCREEN = 1001;
        int HOME = 1002;
        int OTP = 1003;
        int LANGUAGE_SCREEN=1004;
    }

    /**
     * Reference of Application Controller
     */
    private ApplicationController mApplicationController = null;

    /**
     * Constructor
     */
    private ViewFactory() {
        mApplicationController = ApplicationController.getInstance();
    }

    /**
     * This function should only be used when whole application is made by
     * multiple activity.
     *
     * @param id
     * @return Activity class
     */
    public static Class getActivityClass(@ScreenIds int id) {

        switch (id) {
            case LOGIN_SCREEN:
                return ActivityLogin.class;
          /*  case OTP:
                return Otpctivity.class;
            case HOME:
                return HomeActivity.class;
            case LANGUAGE_SCREEN:
                return LaguageActivity.class;*/
            default:
                throw new IllegalStateException("Invalid screen id");
        }

    }


    /**
     * This function should only be used when whole application is made by
     * multiple Fragment.
     *
     * @param id
     * @return Fragment class
     */
    public static Class getFragmentClass(@ScreenIds int id) {

        switch (id) {
            //todo logic for fragments are same
//            case SPLASH_SCREEN: {
//                return SplashActivity.class;
//            }
//
//            case LOGIN_SCREEN: {
//                return LoginActivity.class;
//            }
//
//            case SIGNUP_SCREEN: {
//                return HomeActivity.class;
//            }

            default:
                throw new IllegalStateException("Invalid Event id");

        }

    }
}