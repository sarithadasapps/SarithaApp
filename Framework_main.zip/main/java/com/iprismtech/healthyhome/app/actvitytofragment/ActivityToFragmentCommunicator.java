package com.iprismtech.healthyhome.app.actvitytofragment;

/**
 * Created by Developer on 10/4/2017.
 */

public interface ActivityToFragmentCommunicator {

    void screenID(String screenName);
}
