package com.iprismtech.healthyhome.Fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public abstract class BaseAbstractFragment<T> extends Fragment {

    /**
     * Keeps the generic presenter object so can be used in every fragment.
     */
    protected T presenter;
    protected View view = null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Here get the instance of the view.
        view = getFragmentView();
        initialiseViews();
        setListenerToViews();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    /**
     * Override the getFragmentView() and return inflated view.
     *
     * @return
     */
    protected abstract View getFragmentView();

    /**
     * Sets the listeners to the views
     */
    protected void setListenerToViews() {

    }


    /**
     * Initializes views here, make sure to call findViewById with current view object.
     */
    protected void initialiseViews() {

    }
}
