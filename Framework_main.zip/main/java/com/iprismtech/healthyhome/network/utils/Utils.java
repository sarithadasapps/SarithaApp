package com.iprismtech.healthyhome.network.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.FragmentManager;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;

import com.iprismtech.healthyhome.Dialogues.ProgressDialogLoader;
import com.iprismtech.healthyhome.R;
import com.iprismtech.healthyhome.app.constants.AppConstants;
import com.iprismtech.healthyhome.app.controller.ApplicationController;
import com.iprismtech.healthyhome.network.responcedos.CommonResponse;
import com.iprismtech.healthyhome.network.volley.APIHandler;
import com.iprismtech.healthyhome.others.NetworkCheck;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by prasad on 05/07/2017.
 */
public class Utils {
    private static Utils utilObj;
    ProgressDialogLoader dialog;
    public Boolean isAsyncTaskComplete = true;
    private static final int NETWORK_ERROR_CODE = 5000;
    private static final int ERROR_CODE = 5001;
    private String switchSreen;
    public double latititude=0,longitude=0;

    public boolean isExamStarted() {
        return isExamStarted;
    }

    public void setExamStarted(boolean examStarted) {
        isExamStarted = examStarted;
    }

    public boolean isExamStarted=false;

    public String getExamTitle() {
        return examTitle;
    }

    public void setExamTitle(String examTitle) {
        this.examTitle = examTitle;
    }

    public String examTitle;

    public String getExamtype() {
        return examtype;
    }

    public void setExamtype(String examtype) {
        this.examtype = examtype;
    }

    public String examtype;

    public String getTest_id() {
        return test_id;
    }

    public void setTest_id(String test_id) {
        this.test_id = test_id;
    }

    public String test_id;

    public JSONObject getLoginresponseObj() {
        return loginresponseObj;
    }

    public void setLoginresponseObj(JSONObject loginresponseObj) {
        this.loginresponseObj = loginresponseObj;
    }

    public JSONObject loginresponseObj;



    public static Utils getInstance() {
        if (utilObj == null) {
            utilObj = new Utils();
        }
        return utilObj;
    }


    public String getSwitchSreen() {
        return switchSreen;
    }

    public void setSwitchSreen(String switchSreen) {
        this.switchSreen = switchSreen;
    }

    /**
     * Check internet availability.
     *
     * @param context
     * @return
     */
    public static boolean checkInternetConnection(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connMgr.getActiveNetworkInfo();
        if (activeNetworkInfo != null) { // connected to the internet
            if (activeNetworkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                // connected to wifi
                return true;
            } else if (activeNetworkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                // connected to the mobile provider's data plan
                return true;
            }
        }
        return false;
    }


    /**
     * get the error body for network error
     *
     * @param context
     * @return
     */
    public static String getNetworkErrorBody(Context context) {
        CommonResponse commonResponse = new CommonResponse();
        JSONObject jsonFormat = commonResponse.getJSONFormat(NETWORK_ERROR_CODE, context.getString(R.string.no_internet_txt));

        return jsonFormat.toString();

    }

    /**
     * Construct the error body
     *
     * @param message
     * @return
     */
    public static String constructJSONBody(String message) {
        CommonResponse commonResponse = new CommonResponse();
        JSONObject jsonFormat = commonResponse.getJSONFormat(ERROR_CODE, message);
        return jsonFormat.toString();

    }

    /**
     * Construct json body with eror code and message
     *
     * @param message
     * @param error_code
     * @return
     */
    public static String constructJSONBody(String message, int error_code) {
        CommonResponse commonResponse = new CommonResponse();
        JSONObject jsonFormat = commonResponse.getJSONFormat(error_code, message);
        return jsonFormat.toString();

    }

    /**
     * Show dialog if there is no internet connection.
     *
     * @param dialogTitle
     * @param dialogMessage
     * @param isOutsideCancalabel
     * @param iDialogCallback
     */
    public static void showErrorDialog(final Context context, final String dialogTitle, final String dialogMessage, final boolean isOutsideCancalabel, final APIHandler iDialogCallback, final int requestCode) {
        if (context instanceof Activity) {
            ((Activity) context).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle(dialogTitle);
                    builder.setMessage(dialogMessage);

                    builder.setPositiveButton(context.getString(R.string.ok_txt),
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if (iDialogCallback != null) {
                                        iDialogCallback.onPositiveButtonPress(requestCode);
                                    }
                                    // positive button logic
                                    dialog.dismiss();

                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.setCanceledOnTouchOutside(isOutsideCancalabel);
                    dialog.show();
                }
            });

        }
    }


    /**
     * Encode the string into base64
     *
     * @param text
     * @return
     */
    public static String encodeBase64(String text) {
        byte[] data = new byte[0];
        String encodedString = null;
        try {
            data = text.getBytes("UTF-8");
            encodedString = Base64.encodeToString(data, Base64.DEFAULT);
            Log.d(AppConstants.LOG_CAT, "encodeBase64--" + encodedString);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return encodedString;
    }

    //GEtting location name based on lat lang
    public static String getLocationName(Context context, double latitude, double longitude) {
        String cityName = "Not Found";
        Geocoder gcd = new Geocoder(context, Locale.getDefault());
        try {
            List<Address> addresses = gcd.getFromLocation(latitude, longitude, 10);
            for (Address adrs : addresses) {
                if (adrs != null) {
                    String area = adrs.getFeatureName();
                    String city = adrs.getLocality();
                    String place = adrs.getSubLocality();
                    String state = adrs.getAdminArea();
                    String country = adrs.getCountryName();
                    String postcode = adrs.getPostalCode();
                    if (city != null && !city.equals("")) {
                        cityName = city;
                        return area + ", " + place + ", " + cityName + ", " + state + ", " + country + ", " + postcode;
                    } else {
                    }
                    // // you should also try with addresses.get(0).toSring();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cityName;
    }

    public static void HideKeyboard(View v) {
        try {
            if (v != null) {
                InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Show the progress dilaog when user is displaying progress.
     *
     * @param context
     * @param fragmentManager
     * @param isHidden
     * @param message
     */
    public void Loader(Context context, FragmentManager fragmentManager, Boolean isHidden, String message) {
        try {
            if (message == null) {
                message = "";
            }
            if (isHidden) {
                dialog = new ProgressDialogLoader();
                dialog.setDialogTitle(context, message);
                dialog.setCancelable(false);
                if (dialog != null) {
                    dialog.show(fragmentManager, "DialogLoader");
                    isAsyncTaskComplete = false;
                }
            } else {
                if (dialog != null) {
                    dialog.dismiss();
                    isAsyncTaskComplete = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public String changeDateFormat(String currentFormat, String requiredFormat, String dateString) {
        String result = "";
        SimpleDateFormat formatterOld = new SimpleDateFormat(currentFormat, Locale.getDefault());
        SimpleDateFormat formatterNew = new SimpleDateFormat(requiredFormat, Locale.getDefault());
        Date date = null;
        try {
            date = formatterOld.parse(dateString);
        } catch (java.text.ParseException e) {
            e.printStackTrace();
            Log.v("details2", "" + e.toString());
        }
        if (date != null) {
            result = formatterNew.format(date);
        }
        return result;
    }

    public static void ShowNetworkDialog(final Context context) {
        android.support.v7.app.AlertDialog.Builder b = new android.support.v7.app.AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_network_error, null);
        Button btnOK;
        final boolean[] isCon = {false};
        b.setView(view);
        b.setCancelable(false);
        final android.support.v7.app.AlertDialog dialog = b.create();
        btnOK = view.findViewById(R.id.btnOK);
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isCon[0] = new NetworkCheck().isConnected(context);
                if (isCon[0]) {
                    dialog.dismiss();
                    ApplicationController.getInstance().handleEvent(AppConstants.EventIds.LAUNCH_HOME);

                } else {
                    dialog.show();
                }

            }
        });
        //

        dialog.show();
    }


}
