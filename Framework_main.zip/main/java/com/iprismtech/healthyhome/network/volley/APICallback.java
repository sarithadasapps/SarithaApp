package com.iprismtech.healthyhome.network.volley;

import org.json.JSONObject;

/**
 * Created by prasad on 04/07/2017.
 */
public interface APICallback {
     void onAPISuccessResponse(int requestId, JSONObject responseJsonObject);

     void onAPIFailureResponse(int requestId, JSONObject errorResponseJsonObject);
}
