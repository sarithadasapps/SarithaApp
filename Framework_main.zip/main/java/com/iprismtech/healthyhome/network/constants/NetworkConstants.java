package com.iprismtech.healthyhome.network.constants;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.iprismtech.healthyhome.network.constants.NetworkConstants.RequestCode.USER_LOGIN;


public interface NetworkConstants {
    String PAGE = "?page=";
    String LIMIT = "&limit=";

    interface Headers {
        String X_AUTH_TOKEN = "X-AUTH-TOKEN";
        String BASIC_AUTH_TOKEN = "Authorization";
    }

    interface URL {
        //String PRIMARY_BASE_URL = BuildConfig.BASE_URL;

        // String BASE_URL = BuildConfig.BASE_URL;

        String IMAGEPATH="http://mobileappdevelopmentsolutions.com/onlyexam/";
        String BASE_URL = "http://mobileappdevelopmentsolutions.com/onlyexam/public/ws/";
        String GetTOKEN=BASE_URL+"get_token";
        String SEND_OTP = BASE_URL + "send_otp";
        String GET_QUESTIONS = BASE_URL + "get_questions";
        String SubmitAnswer=BASE_URL+"question_answer";
        String FinishTEST=BASE_URL+"finish_test";
        String ReportQuestion=BASE_URL+"report_question";
        String GiveRating=BASE_URL+"give_rating";
        String GET_UnAttemptedTests=BASE_URL+"get_tests";
        String Unfinished_Tests=BASE_URL+"unfinished_tests";
        String Finished_Tests=BASE_URL+"finished_tests";
        String RankRating=BASE_URL+"tests_ratings";
        String StartTest=BASE_URL+"start_test";
        String Answered_Questions=BASE_URL+"answered_questions";


    }


    /**
     * Application Controller events ids
     * Maintain all app level event ids and def of that event ids
     */
    @Retention(RetentionPolicy.CLASS)
    @IntDef({USER_LOGIN})
    @interface RequestCode {

        int USER_LOGIN = 110;
        int GET_TOKEN=111;
        int GETOTP=112;
        int GETQUESTIONS=113;
        int SUBMITANSWER=114;
        int FINISH_TEST=115;
        int REPORT_QUESTION=116;
        int GIVERATING=117;
        int UNATTEMPTED=118;
        int ATTEMPTED=119;
        int UNFINISIHED=120;
        int STARTTEST=121;
        int RANKRATING=122;
        int ANSWERED_QUESTIONS=123;


        int SUCCESS = 200;
        int SESSION_EXPIRE = 1017;
    }

}