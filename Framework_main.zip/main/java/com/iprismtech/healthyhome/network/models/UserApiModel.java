package com.iprismtech.healthyhome.network.models;

import android.content.Context;

import com.android.volley.Request;
import com.iprismtech.healthyhome.R;
import com.iprismtech.healthyhome.network.constants.NetworkConstants;
import com.iprismtech.healthyhome.network.listener.APIResponseCallback;
import com.iprismtech.healthyhome.network.volley.APIHandler;

import org.json.JSONObject;

import java.util.Map;

/**
 * Created by Prasad on 7/25/2017.
 */
public class UserApiModel extends BaseApiModel {

    public UserApiModel(Context context, APIResponseCallback apiResponseCallback) {
        super(context);
        this.context = context;
        this.apiResponseCallback = apiResponseCallback;
    }

    public void getToken(@NetworkConstants.RequestCode int requestId, Map<String,String> params) {
        System.out.println("Login >>>>>>>>>>>>>>>>>>>");
        apiHandler = new APIHandler(context, this, requestId, Request.Method.GET,
                NetworkConstants.URL.GetTOKEN, true, false,
                context.getString(R.string.pleasewait), params, getHeader());
        apiHandler.requestAPI();
    }
    public void getOTP(@NetworkConstants.RequestCode int requestId, Map<String,String> params) {
        System.out.println("Login >>>>>>>>>>>>>>>>>>>");
        apiHandler = new APIHandler(context, this, requestId, Request.Method.POST,
                NetworkConstants.URL.SEND_OTP, true, false,
                context.getString(R.string.pleasewait), params, getHeader());
        apiHandler.requestAPI();
    }

    @Override
    public void onAPISuccessResponse(int requestId, JSONObject responseString) {
        super.onAPISuccessResponse(requestId,  responseString);

        System.out.println("Response successfully >>>>>>>>>>>>>>>>>>>>>>>>>>>" + responseString.toString());

        if(apiResponseCallback!=null){
            apiResponseCallback.onSuccessResponse(requestId,responseString,null);
        }

    }

    @Override
    public void onAPIFailureResponse(int requestId, JSONObject errorString) {
        super.onAPIFailureResponse(requestId, errorString);
    }
}
