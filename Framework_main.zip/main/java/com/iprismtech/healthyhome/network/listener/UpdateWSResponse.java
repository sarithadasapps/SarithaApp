package com.iprismtech.healthyhome.network.listener;

/**
 * Created by Developer on 22/2/17.
 */

public interface UpdateWSResponse {
    void updateWSResponse(String response, String requestType);
}