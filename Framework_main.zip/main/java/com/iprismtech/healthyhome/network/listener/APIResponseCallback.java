package com.iprismtech.healthyhome.network.listener;

import android.support.annotation.Nullable;

import com.iprismtech.healthyhome.network.constants.NetworkConstants;

import org.json.JSONObject;


/**
 * Created by prasad on 05/07/2017
 */

public interface APIResponseCallback {

    void onSuccessResponse(@NetworkConstants.RequestCode int requestId, JSONObject responseJsonObject,
                           @Nullable Object object);

    void onFailureResponse(@NetworkConstants.RequestCode int requestId, JSONObject errorJsonObject);

}
