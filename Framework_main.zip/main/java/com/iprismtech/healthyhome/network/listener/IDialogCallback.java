package com.iprismtech.healthyhome.network.listener;

/**
 * Created by prasad on 05/07/2017.
 */
public interface IDialogCallback {

    void onPositiveButtonPress(int requestCode);

    void onNegativeButtonPress(int requestCode);
}
