package com.iprismtech.healthyhome.Dialogues;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;

import com.iprismtech.healthyhome.R;
import com.iprismtech.healthyhome.activity.ActivitySplash;
import com.iprismtech.healthyhome.network.utils.NetworkChangeReceiver;
import com.iprismtech.healthyhome.network.utils.Utils;


/**
 * Created by DEVELOPER on 23-Mar-17.
 */

public class NetworkErrorDialog extends DialogFragment implements View.OnClickListener {
    private Button okButton;
    private Context context;
    private FragmentManager fragmentManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Translucent_NoTitleBar);
    }

    public void setDialogTitle(Context ctx) {
        context = ctx;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.network_dialog_layout, null);

        initialiseViews(view);
        registerEvents();

        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(false);
        getDialog().setCancelable(false);

        return view;
    }

    /**
     * Method is use to perform the click events.
     */
    private void registerEvents() {
        okButton.setOnClickListener(this);
    }

    /**
     * Function is use to initialise the views here.
     *
     * @param view
     */
    private void initialiseViews(View view) {
        okButton = view.findViewById(R.id.btnOK);
        fragmentManager = getFragmentManager();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnOK:
                 Utils.getInstance().Loader(context, fragmentManager, false, null);
                //Checking condition if network availble then start app.
                if (NetworkChangeReceiver.isNetworkAvailable(context)) {
                    //ApplicationController.getInstance().handleEvent(AppConstants.EventIds.);
                    Intent intent = new Intent(context, ActivitySplash.class);
                    context.startActivity(intent);
                    dismiss();
                } else {
                    //Checking if dialog open then close the dialog and show new dialog that network not available.
                    dismiss();
                    NetworkErrorDialog networkErrorDialog = new NetworkErrorDialog();
                    networkErrorDialog.setDialogTitle(context);
                    networkErrorDialog.show(fragmentManager, "");
                }

                break;
        }
    }
}
