package com.iprismtech.healthyhome.Dialogues;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.iprismtech.healthyhome.R;


/**
 * Created by DEVELOPER on 23-Mar-17.
 */

public class ProgressDialogLoader extends DialogFragment {
    Context context;
    String message = "";
    private ImageView progressImageView;
    private TextView pleasewaitTextView;

    //---empty constructor required
    public ProgressDialogLoader() {
    }

    public void setDialogTitle(Context ctx, String msg) {
        context = ctx;
        message = msg;
        if (message == null) {
            message = "";
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen);
       // setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_DeviceDefault_Dialog);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {
        View view = inflater.inflate(R.layout.dialog_loader_progress, container);

        initialiseView(view);

        progressImageView = view.findViewById(R.id.progressImageVeiw);

        //Load the progress dialog here.
       // Util.getInstance().loadImage(context, progressImageView);
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        getDialog().setCanceledOnTouchOutside(true);
        getDialog().setCancelable(false);
        return view;
    }

    /**
     * This function is use to initialise the views.
     *
     * @param view
     */
    private void initialiseView(View view) {
        pleasewaitTextView = view.findViewById(R.id.progressTextView);
    }
}
