package com.iprismtech.healthyhome.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.iprismtech.healthyhome.R;
import com.iprismtech.healthyhome.Typeface.CustomFontLoader;
import com.iprismtech.healthyhome.network.listener.APIResponseCallback;
import com.iprismtech.healthyhome.others.HelperObj;

import org.json.JSONObject;

public class ActivityLogin extends BaseAbstractActivity implements APIResponseCallback{

    CustomFontLoader fontLoader;
    Context context;
    TextView logintouract_tv,forgotpwd_tv,createaccount_tv;
    EditText email_et,pwd_et;
    Button login_btn;
    LinearLayout createaccount_ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected View getView() {
        View view=getLayoutInflater().inflate(R.layout.activity_login,null);
        return view;
    }

    @Override
    protected void initializeViews() {
        super.initializeViews();
        context=this;
        fontLoader=new CustomFontLoader();
        logintouract_tv=findViewById(R.id.logintouract_tv);
        forgotpwd_tv=findViewById(R.id.forgotpwd_tv);
        email_et=findViewById(R.id.email_et);
        pwd_et=findViewById(R.id.pwd_et);
        login_btn=findViewById(R.id.login_btn);
        createaccount_ll=findViewById(R.id.createaccount_ll);
        createaccount_tv=findViewById(R.id.createaccount_tv);

        logintouract_tv.setTypeface(fontLoader.getTypeface(context,1));
        forgotpwd_tv.setTypeface(fontLoader.getTypeface(context,1));
        email_et.setTypeface(fontLoader.getTypeface(context,0));
        pwd_et.setTypeface(fontLoader.getTypeface(context,0));
        login_btn.setTypeface(fontLoader.getTypeface(context,1));
        createaccount_tv.setTypeface(fontLoader.getTypeface(context,1));

    }

    @Override
    protected void setListenerToViews() {
        super.setListenerToViews();
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HelperObj.getInstance().cusToast(context,"login");
            }
        });
    }

    @Override
    public void onSuccessResponse(int requestId, JSONObject responseJsonObject, @Nullable Object object) {

    }

    @Override
    public void onFailureResponse(int requestId, JSONObject errorJsonObject) {

    }
}
