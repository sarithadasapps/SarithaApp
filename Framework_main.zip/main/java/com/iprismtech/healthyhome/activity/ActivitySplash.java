package com.iprismtech.healthyhome.activity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import com.iprismtech.healthyhome.R;
import com.iprismtech.healthyhome.app.constants.AppConstants;
import com.iprismtech.healthyhome.app.controller.ApplicationController;
import com.iprismtech.healthyhome.others.UserSession;

import java.util.Locale;

public class ActivitySplash extends BaseAbstractActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected View getView() {

        View view=getLayoutInflater().inflate(R.layout.activity_splash,null);
        return view;
    }

    @Override
    protected void initializeViews() {
        super.initializeViews();
        context=this;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (UserSession.getInstance(context).isUserLoggedIn()){
                  /*  selectedLanguage=UserSession.getInstance(context).GetSelectedLanguage();
                    if (selectedLanguage.equals("telugu")) {
                        UserSession.getInstance(context).SaveSelectedLanguage("telugu");
                        UserSession.getInstance(context).SetLanguageSelection(true);
                        String languageToLoad = "te"; // your language
                        Locale locale = new Locale(languageToLoad);
                        Locale.setDefault(locale);
                        Configuration config = new Configuration();
                        config.locale = locale;
                        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
                    } else {
                        UserSession.getInstance(context).SaveSelectedLanguage("english");
                        UserSession.getInstance(context).SetLanguageSelection(false);
                        String languageToLoad = "en"; // your language
                        Locale locale = new Locale(languageToLoad);
                        Locale.setDefault(locale);
                        Configuration config = new Configuration();
                        config.locale = locale;
                        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());

                    }
                    ApplicationController.getInstance().handleEvent(AppConstants.EventIds.LAUNCH_HOME);
                    finish();*/
                }else{
                    ApplicationController.getInstance().handleEvent(AppConstants.EventIds.LAUNCH_LOGIN_SCREEN);
                    finish();
                }

            }
        },3000);
    }
}
